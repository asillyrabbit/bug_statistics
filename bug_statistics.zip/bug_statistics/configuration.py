#! python3

import pymysql

# 项目信息
project_name = 'v1.5.4'

# 当前目录
current_dir = '/opt/bug_statistics/'

# 建立数据库连接
conn = pymysql.connect(
    host='127.0.0.1',
    port=3307,
    user='root',
    passwd='123456',
    db='zentao',
    charset='utf8')

# 接收邮箱
email_address_list = ['niejun@xlyhw.com','mazhiyuan@xlyhw.com','liuchanglei@xlyhw.com']
