import sys

filename = '/opt/bug_statistics/configuration.py'

name = sys.argv[1]
new_line = f"project_name = '{name}'"
flag = 0

with open(filename, encoding='utf-8') as f:
    message = ''
    for line in f:
        if new_line == line.strip():
            flag = 1
            break
        if line.startswith('project_name'):
            line = line.replace(line, f"project_name = '{name}'\n")
        message += line

if flag == 1:
    pass
else:
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(message)
