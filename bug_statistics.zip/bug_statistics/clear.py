import send2trash
import configuration
import os

os.chdir(configuration.current_dir)

# 删除本地文件
for filename in os.listdir():
    if filename.endswith('-测试日报.xlsx'):
        send2trash.send2trash(filename)
